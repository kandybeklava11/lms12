public class Car {
    private String marka;
    private int yaer;
    private String price;

    public String getMarka() {
        return marka;
    }

    public int getYaer() {
        return yaer;
    }

    public String getPrice() {
        return price;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public void setYaer(int yaer) {
        this.yaer = yaer;
    }

    public void setPrice(String price) {
        this.price = price;
    }


}
